﻿using System.Collections.Generic;

namespace WebApplication2.Models
{
    public class ProductListViewModel
    {
        public List<Product> Products { get; set; }  // List of products for the current page
        public int PageIndex { get; set; }  // Current page number
        public int PageSize { get; set; }  // Number of items per page
        public int TotalCount { get; set; }  // Total number of items in the dataset
        public int TotalPages { get; set; }  // Total number of pages
    }
}
