﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using System.Threading.Tasks;
using WebApplication2.Models;
using Microsoft.AspNetCore.Authorization;

namespace WebApplication2.Controllers
{
    public class AccountController : Controller
    {
        // services provided by ASP.NET Core Identity
        private readonly UserManager<IdentityUser> _userManager;
        private readonly SignInManager<IdentityUser> _signInManager;

        public AccountController(UserManager<IdentityUser> userManager, SignInManager<IdentityUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        // GET: Displays the Register view
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        // This method accepts a RegisterViewModel, which contains the user's input
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = new IdentityUser { UserName = model.Email, Email = model.Email };


                // Create the user asynchronously
                var result = await _userManager.CreateAsync(user, model.Password);

                if (result.Succeeded)
                {
                    await _signInManager.SignInAsync(user, isPersistent: false);
                    //return RedirectToAction("Login", "Account");
                    return View("~/Views/Account/Login.cshtml");
                    // Redirect to the Login page after successful registration
                    
                }
                

                // Add errors if registration failed
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }

            return View("~/Views/Account/Login.cshtml");
        }

        // GET: Displays the Login view
        public IActionResult Login()
        {
            return View();
        }
        // This method handles the login process
        [HttpPost]
        // This method handles the login process
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Attempt to sign in the user
                var result = await _signInManager.PasswordSignInAsync(model.Email, model.Password, false, false);

                if (result.Succeeded)
                {
                    // Redirect to the returnUrl or the Products page
                    return RedirectToAction("Create","Products");
                }

                // Add error if login failed
                ModelState.AddModelError("", "Invalid login attempt");
            }

            return View(("Create"));
        }
        // Helper method to redirect to local URLs
        //private IActionResult RedirectToLocal(string returnUrl)
        //{
        //    if (Url.IsLocalUrl(returnUrl))
        //    {
        //        Console.WriteLine("Redirecting to local URL: " + returnUrl);
        //        return Redirect(returnUrl);  // Redirect back to the returnUrl if it's a valid local URL
        //    }
        //    else
        //    {

        //        return RedirectToAction("Index", "Products");  // Default redirection to Products if returnUrl is null or invalid
        //    }
        //}

        // Logout Action
        public async Task<IActionResult> Logout()
        {
            // Sign the user out
            await _signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");  // Redirect to Home after logging out
        }
    }
}

