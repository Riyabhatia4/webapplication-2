﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using WebApplication2.Models;
using WebApplication2.Data;
using WebApplication2.Repositories; // Make sure this is properly included

namespace WebApplication2.Controllers
{
    public class ProductsController : Controller
    {
        private readonly AppDbContext _context;
        private readonly IProductRepository _repo;

        public ProductsController(AppDbContext context, IProductRepository repo)
        {
            _context = context;
            _repo = repo;
        }

        public async Task<IActionResult> Index(int pageIndex = 1, int pageSize = 10)
        {
            // Get the total count of products
            var totalCount = await _context.Products.CountAsync();

            // Get the paginated products based on the current page
            var products = await _context.Products
                .Skip((pageIndex - 1) * pageSize)  // Skip records for previous pages
                .Take(pageSize)  // Take only the records for the current page
                .ToListAsync();

            // Calculate total pages
            var totalPages = (int)Math.Ceiling(totalCount / (double)pageSize);

            // Prepare ViewModel for pagination data
            var viewModel = new ProductListViewModel
            {
                Products = products,
                PageIndex = pageIndex,
                PageSize = pageSize,
                TotalCount = totalCount,
                TotalPages = totalPages
            };

            return View(viewModel);
        }

        // Create Action - Display Create Form (GET)
        public IActionResult Create()
        {
            return View(new Product());
        }

        // Create Action - Handle form submission (POST)
        [HttpPost]
        public async Task<IActionResult> Create(Product product)
        {
            if (ModelState.IsValid)
            {
                _context.Products.Add(product);     // Adds a new product
                await _context.SaveChangesAsync();  // Saves the changes asynchronously
                return RedirectToAction(nameof(Index)); // Redirect to the Index page after saving
            }
            return View(product);
        }

        // Edit Action - Display Edit Form (GET)
        public async Task<IActionResult> Edit(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        // Edit Action - Handle form submission (POST)
        [HttpPost]
        
        public async Task<IActionResult> Edit(int id, Product product)
        {
            Console.WriteLine($"jsknnskjbkbdkvbsbDSBKSB{id}{product}");
            if (id != product.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(product);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductExists(product.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }
            return View(product);
        }

        // Delete Action - Display Delete Confirmation Form (GET)

     
        public async Task<IActionResult> Delete(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        // Delete Action - Handle form submission (POST)
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product != null)
            {
                _context.Products.Remove(product);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        // Helper method to check if a product exists
        private bool ProductExists(int id)
        {
            return _context.Products.Any(e => e.Id == id);
        }
    }
}
